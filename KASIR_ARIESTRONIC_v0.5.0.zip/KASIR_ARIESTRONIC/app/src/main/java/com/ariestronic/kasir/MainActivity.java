package com.ariestronic.kasir;

import android.app.*;
import android.Manifest;
import android.bluetooth.*;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.os.*;
import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.text.NumberFormat;
import java.util.*;
import java.nio.charset.Charset;
import java.util.UUID;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class MainActivity extends Activity {
    private static final int GREEN = 0xFF56B96B, PALE = 0xFFEAF7EC, DARK = 0xFF203126;
    private DB db; private LinearLayout root, body, nav; private TextView title;
    private EditText scanInput; private final ArrayList<CartItem> cart = new ArrayList<>();
    private final NumberFormat rupiah = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));
    private int totalCart = 0; private static final int REQ_BT=220; private static final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"); private String lastReceipt="", pendingBarcode="";

    @Override public void onCreate(Bundle b) { super.onCreate(b); db = new DB(this); showHome(); }
    private void shell(String heading) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(0xFFFFFFFF);
        TextView brand = new TextView(this); brand.setText("KASIR ARIESTRONIC"); brand.setTextColor(DARK); brand.setTextSize(20); brand.setTypeface(null, Typeface.BOLD); brand.setPadding(18,18,18,2); root.addView(brand);
        title = new TextView(this); title.setText(heading); title.setTextColor(GREEN); title.setTextSize(15); title.setPadding(18,2,18,12); root.addView(title);
        ScrollView sc = new ScrollView(this); body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(16,8,16,18); sc.addView(body); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        nav = new LinearLayout(this); nav.setPadding(5,7,5,7); nav.setBackgroundColor(PALE); root.addView(nav);
        navButton("Kasir", this::showHome); navButton("Barang", this::showProducts); navButton("Laporan", this::showReports); navButton("Toko/Backup", this::showSettings);
        setContentView(root);
    }
    private void navButton(String s, Runnable r) { Button b = new Button(this); b.setText(s); b.setTextSize(11); b.setAllCaps(false); b.setTextColor(DARK); b.setOnClickListener(v -> r.run()); nav.addView(b,new LinearLayout.LayoutParams(0,-2,1)); }
    private TextView label(String s) { TextView t=new TextView(this); t.setText(s); t.setTextColor(DARK); t.setTextSize(14); t.setPadding(0,10,0,4); return t; }
    private EditText input(String hint) { EditText e=new EditText(this); e.setSingleLine(true); e.setTextSize(15); e.setHint(hint); e.setPadding(12,8,12,8); e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GREEN)); body.addView(e); return e; }
    private Button button(String s, Runnable r) { Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(0xFFFFFFFF); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GREEN)); b.setOnClickListener(v->r.run()); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,8,0,4); body.addView(b,p); return b; }
    private void line() { View v=new View(this); v.setBackgroundColor(0xFFE3EDE5); body.addView(v,new LinearLayout.LayoutParams(-1,1)); }
    private String money(long n) { return rupiah.format(n); }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }

    private void showHome() {
        shell("Kasir penjualan");
        TextView hint=label("Pindai barcode dengan scanner Bluetooth/USB (mode keyboard/HID), atau ketik kode barang:"); body.addView(hint);
        scanInput=input("Scan / masukkan barcode lalu tekan Enter");
        scanInput.setImeOptions(EditorInfo.IME_ACTION_DONE);
        scanInput.setOnEditorActionListener((v,a,event)->{ String code=scanInput.getText().toString().trim(); scanInput.setText(""); addScanned(code); scanInput.requestFocus(); return true; });
        button("Tambah barang ke keranjang",()->{ addScanned(scanInput.getText().toString().trim()); scanInput.setText(""); });
        button("Scan dengan kamera HP",()->startCameraScan());
        line(); body.addView(label("KERANJANG"));
        renderCart();
    }
    private void addScanned(String code) {
        if(code.isEmpty()){toast("Masukkan atau scan barcode terlebih dahulu");return;}
        Product p=db.byBarcode(code); if(p==null){ new AlertDialog.Builder(this).setTitle("Barcode belum terdaftar").setMessage("Tambahkan barang dengan kode "+code+"?").setNegativeButton("Batal",null).setPositiveButton("Tambah barang",(d,w)->{pendingBarcode=code;showProducts();}).show(); return; }
        if(p.stock<=0){toast("Stok barang habis");return;}
        for(CartItem c:cart) if(c.product.id==p.id){ if(c.qty<p.stock)c.qty++; else toast("Jumlah melebihi stok"); showHome(); return; }
        cart.add(new CartItem(p,1)); showHome();
    }
    private void renderCart() {
        long total=0;
        if(cart.isEmpty()) body.addView(label("Keranjang masih kosong."));
        for(int i=0;i<cart.size();i++) {
            final int ix=i; CartItem c=cart.get(i); total+=(long)c.qty*c.product.price;
            TextView row=label(c.product.name+"\n"+money(c.product.price)+" × "+c.qty+" = "+money(c.product.price*c.qty)); body.addView(row);
            LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
            Button minus=new Button(this); minus.setText("−"); minus.setOnClickListener(v->{if(c.qty>1)c.qty--;else cart.remove(ix);showHome();}); actions.addView(minus,new LinearLayout.LayoutParams(0,-2,1));
            Button plus=new Button(this); plus.setText("+"); plus.setOnClickListener(v->{Product fresh=db.byBarcode(c.product.barcode);if(fresh!=null && c.qty<fresh.stock)c.qty++;else toast("Jumlah melebihi stok tersedia");showHome();}); actions.addView(plus,new LinearLayout.LayoutParams(0,-2,1));
            Button del=new Button(this); del.setText("Hapus"); del.setOnClickListener(v->{cart.remove(ix);showHome();}); actions.addView(del,new LinearLayout.LayoutParams(0,-2,1));
            body.addView(actions); line();
        }
        final long amount=total; body.addView(label("TOTAL: "+money(amount)));
        button("PROSES PEMBAYARAN",()->checkout(amount));
        button("Kosongkan keranjang",()->{cart.clear();showHome();});
    }
    private void checkout(long ignoredAmount) {
        if(cart.isEmpty()){toast("Keranjang kosong");return;}
        // Refresh each item from the database so a price/stock edit made while
        // the cart was open cannot produce a stale total.
        long currentTotal=0;
        for(CartItem item:cart){
            Product latest=db.byBarcode(item.product.barcode);
            if(latest==null){toast("Barang "+item.product.name+" tidak lagi tersedia");return;}
            if(latest.stock<item.qty){toast("Stok "+latest.name+" hanya tersisa "+latest.stock);return;}
            item.product=latest;
            currentTotal+=(long)latest.price*item.qty;
        }
        final long amount=currentTotal;
        EditText paid=new EditText(this); paid.setHint("Uang diterima (angka)"); paid.setInputType(2);
        new AlertDialog.Builder(this).setTitle("Pembayaran "+money(amount)).setView(paid).setNegativeButton("Batal",null).setPositiveButton("Simpan transaksi",(d,w)->{
            long cash=0; try{cash=Long.parseLong(paid.getText().toString());}catch(Exception ignored){}
            if(cash<amount){toast("Uang pembayaran kurang");return;}
            long saleId;
            try { saleId=db.saveSale(cart,amount,cash); }
            catch(Exception ex) { toast("Transaksi tidak tersimpan: "+ex.getMessage()); return; }
            String receipt=db.setting("shop_name","KASIR ARIESTRONIC")+"\n"+db.setting("shop_address","")+"\n"+db.setting("shop_phone","")+"\nTransaksi #"+saleId+"\n----------------------\n";
            for(CartItem c:cart) receipt+=c.product.name+" x"+c.qty+"  "+money(c.qty*c.product.price)+"\n";
            receipt+="----------------------\nTOTAL "+money(amount)+"\nBAYAR "+money(cash)+"\nKEMBALI "+money(cash-amount)+"\nTerima kasih";
            lastReceipt=receipt; cart.clear(); new AlertDialog.Builder(this).setTitle("Transaksi tersimpan").setMessage(receipt).setNeutralButton("Cetak struk",(x,y)->printText(receipt+"\nTerima kasih\n\n\n")).setPositiveButton("Selesai",(x,y)->showHome()).show();
        }).show();
    }

    private void showProducts() {
        shell("Data barang & stok");
        EditText name=input("Nama barang"); EditText barcode=input("Barcode / kode barang"); if(!pendingBarcode.isEmpty()){barcode.setText(pendingBarcode);pendingBarcode="";} EditText cost=input("Harga modal (angka)"); cost.setInputType(2); EditText price=input("Harga jual (angka)"); price.setInputType(2); EditText stock=input("Stok awal"); stock.setInputType(2);
        button("Buat kode barang otomatis",()->barcode.setText("AR"+new java.text.SimpleDateFormat("yyMMddHHmmss",Locale.US).format(new Date())+String.format(Locale.US,"%02d",new Random().nextInt(100))));
        button("Simpan barang",()->{String n=name.getText().toString().trim(), bc=barcode.getText().toString().trim(); if(n.isEmpty()||bc.isEmpty()){toast("Nama dan barcode wajib diisi");return;} long pr=parse(price.getText().toString()), co=parse(cost.getText().toString()); int st=(int)parse(stock.getText().toString()); if(pr<0||co<0||st<0){toast("Harga/stok tidak valid");return;} if(db.upsert(n,bc,co,pr,st)) {toast("Barang disimpan");showProducts();} else toast("Barcode sudah digunakan barang lain");});
        line(); body.addView(label("DAFTAR BARANG"));
        EditText filter=input("Cari nama barang / barcode");
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); body.addView(list);
        Runnable refresh=()->{
            list.removeAllViews(); String q=filter.getText().toString().trim().toLowerCase(Locale.ROOT);
            Cursor c=db.getProducts(); while(c.moveToNext()) { int id=c.getInt(0); String n=c.getString(1), bc=c.getString(2); long co=c.getLong(3), pr=c.getLong(4); int st=c.getInt(5);
                if(!q.isEmpty() && !n.toLowerCase(Locale.ROOT).contains(q) && !bc.toLowerCase(Locale.ROOT).contains(q)) continue;
                TextView t=label(n+"\nKode: "+bc+" | Modal: "+money(co)+" | Jual: "+money(pr)+" | Stok: "+st); list.addView(t);
                if(st<=5){ TextView warning=label(st==0?"PERINGATAN: STOK HABIS":"PERINGATAN: STOK MENIPIS (≤ 5)"); warning.setTextColor(0xFFB3261E); warning.setTypeface(null,Typeface.BOLD); list.addView(warning); }
                Button edit=new Button(this); edit.setText("Edit barang / harga / stok"); edit.setAllCaps(false); edit.setOnClickListener(v->editProduct(id,n,bc,co,pr,st)); list.addView(edit);
                Button lbl=new Button(this); lbl.setText("Cetak label barcode"); lbl.setAllCaps(false); lbl.setOnClickListener(v->printLabel(n,bc,pr)); list.addView(lbl); line();
            } c.close();
        };
        filter.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence x,int st,int count,int after){} public void onTextChanged(CharSequence x,int st,int before,int count){refresh.run();} public void afterTextChanged(android.text.Editable e){}});
        refresh.run();
    }
    private void editProduct(int id,String n,String bc,long oldCost,long oldPrice,int oldStock) {
        LinearLayout box=new LinearLayout(this); box.setPadding(20,5,20,5); box.setOrientation(1);
        EditText nameEdit=new EditText(this); nameEdit.setHint("Nama barang"); nameEdit.setText(n); box.addView(nameEdit);
        EditText barcodeEdit=new EditText(this); barcodeEdit.setHint("Barcode / kode barang"); barcodeEdit.setText(bc); box.addView(barcodeEdit);
        EditText co=new EditText(this); co.setHint("Harga modal"); co.setInputType(2); co.setText(String.valueOf(oldCost)); box.addView(co);
        EditText p=new EditText(this); p.setHint("Harga jual"); p.setInputType(2); p.setText(String.valueOf(oldPrice)); box.addView(p);
        EditText st=new EditText(this); st.setHint("Stok"); st.setInputType(2); st.setText(String.valueOf(oldStock)); box.addView(st);
        new AlertDialog.Builder(this).setTitle("Edit: "+n).setView(box).setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,w)->{
            String nn=nameEdit.getText().toString().trim(), bb=barcodeEdit.getText().toString().trim(); long cc=parse(co.getText().toString()), pp=parse(p.getText().toString()); int ss=(int)parse(st.getText().toString());
            if(nn.isEmpty()||bb.isEmpty()||cc<0||pp<0||ss<0){toast("Periksa nama, barcode, harga, dan stok");return;}
            if(db.updateProduct(id,nn,bb,cc,pp,ss)){toast("Barang diperbarui");showProducts();}else toast("Gagal: barcode mungkin sudah dipakai barang lain");
        }).show();
    }

    private void showReports() {
        shell("Laporan penjualan");
        long sum=db.totalSales(); int count=db.saleCount(); long profit=db.totalProfit();
        body.addView(label("Omzet hari ini: "+money(db.salesToday()))); body.addView(label("Omzet bulan ini: "+money(db.salesThisMonth())));
        body.addView(label("Total omzet tersimpan: "+money(sum))); body.addView(label("Estimasi laba kotor: "+money(profit))); body.addView(label("Jumlah transaksi: "+count));
        line(); body.addView(label("Riwayat transaksi terbaru")); Cursor c=db.sales();
        while(c.moveToNext()) body.addView(label("#"+c.getLong(0)+"  •  "+c.getString(1)+"\nTotal: "+money(c.getLong(2)))); c.close();
    }
    private void showSettings() {
        shell("Profil toko & backup");
        EditText n=input("Nama toko"); n.setText(db.setting("shop_name","KASIR ARIESTRONIC"));
        EditText a=input("Alamat toko"); a.setText(db.setting("shop_address",""));
        EditText h=input("Nomor HP toko"); h.setText(db.setting("shop_phone",""));
        button("Simpan profil toko",()->{db.setSetting("shop_name",n.getText().toString());db.setSetting("shop_address",a.getText().toString());db.setSetting("shop_phone",h.getText().toString());toast("Profil toko disimpan");});
        line(); body.addView(label("Backup menyimpan database barang, stok, profil, dan transaksi."));
        button("Backup database ke Google Drive",()->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_TITLE,"backup_kasir_ariestronic.db");startActivityForResult(i,101);});
        button("Pulihkan backup dari Google Drive",()->new AlertDialog.Builder(this).setTitle("Pulihkan data?").setMessage("Data toko saat ini akan diganti oleh file backup yang dipilih. Pastikan Anda sudah membuat backup terbaru.").setNegativeButton("Batal",null).setPositiveButton("Lanjut",(d,w)->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");startActivityForResult(i,102);}).show());
        button("Pilih printer Bluetooth",()->choosePrinter());
        button("Cetak tes printer",()->printText(db.setting("shop_name","KASIR ARIESTRONIC")+"\nTes printer berhasil.\n\n\n"));
        body.addView(label("Printer tersimpan: "+db.setting("printer_name","Belum dipilih")+". Kertas: "+db.setting("paper_width","58")+" mm"));
        button("Atur lebar kertas 58 / 80 mm",()->new AlertDialog.Builder(this).setTitle("Lebar kertas printer").setItems(new String[]{"58 mm","80 mm"},(d,w)->{db.setSetting("paper_width",w==0?"58":"80");showSettings();}).show());
        body.addView(label("Catatan: Google Drive dipilih melalui pemilih file Android. Backup/restore memerlukan internet dan aplikasi Google Drive yang terhubung."));
    }
    private void startCameraScan(){
        IntentIntegrator scan=new IntentIntegrator(this); scan.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES); scan.setPrompt("Arahkan kamera ke barcode barang"); scan.setBeepEnabled(true); scan.setOrientationLocked(false); scan.initiateScan();
    }
    private void choosePrinter(){
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);return;}
        BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter(); if(a==null){toast("HP tidak mendukung Bluetooth");return;} if(!a.isEnabled()){startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));return;}
        try{Set<BluetoothDevice> devices=a.getBondedDevices(); ArrayList<BluetoothDevice> list=new ArrayList<>(devices); if(list.isEmpty()){toast("Pairing printer dari pengaturan Bluetooth HP terlebih dahulu");return;} String[] names=new String[list.size()]; for(int i=0;i<list.size();i++)names[i]=list.get(i).getName()+"\n"+list.get(i).getAddress(); new AlertDialog.Builder(this).setTitle("Pilih printer yang sudah dipasangkan").setItems(names,(d,w)->{db.setSetting("printer_mac",list.get(w).getAddress());db.setSetting("printer_name",list.get(w).getName());toast("Printer dipilih");showSettings();}).show();}catch(SecurityException e){toast("Izin Bluetooth diperlukan");}
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_BT && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED)choosePrinter();}
    private String formatReceipt(String text){
        int columns="80".equals(db.setting("paper_width","58"))?48:32;
        StringBuilder result=new StringBuilder();
        for(String original:text.split("\\n",-1)){
            String line=original;
            if(line.isEmpty()){result.append('\n');continue;}
            while(line.length()>columns){
                int cut=line.lastIndexOf(' ',columns);
                if(cut<1)cut=columns;
                result.append(line,0,cut).append('\n');
                line=line.substring(cut).trim();
            }
            result.append(line).append('\n');
        }
        return result.toString();
    }
    private void printText(String text){String printable=formatReceipt(text);new Thread(()->{try{BluetoothSocket socket=openPrinter();OutputStream out=socket.getOutputStream();out.write(new byte[]{0x1B,0x40});out.write(printable.getBytes("GBK"));out.write(new byte[]{0x1D,0x56,0x00});out.flush();socket.close();runOnUiThread(()->toast("Struk dikirim ke printer"));}catch(Exception e){runOnUiThread(()->toast("Gagal mencetak: "+e.getMessage()));}}).start();}
    private BluetoothSocket openPrinter() throws Exception {if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)throw new SecurityException("Izin Bluetooth belum diberikan");String mac=db.setting("printer_mac","");if(mac.isEmpty())throw new Exception("Pilih printer Bluetooth di menu Toko/Backup");BluetoothDevice device=BluetoothAdapter.getDefaultAdapter().getRemoteDevice(mac);BluetoothSocket s=device.createRfcommSocketToServiceRecord(SPP);s.connect();return s;}
    private void printLabel(String name,String code,long price){String width=db.setting("paper_width","58");new Thread(()->{try{BluetoothSocket socket=openPrinter();OutputStream out=socket.getOutputStream();out.write(new byte[]{0x1B,0x40,0x1B,0x61,0x01});out.write((name+"\n"+money(price)+"\n").getBytes("GBK"));byte[] bc=("{B"+code).getBytes(Charset.forName("US-ASCII"));out.write(new byte[]{0x1D,0x6B,0x49,(byte)bc.length});out.write(bc);out.write(new byte[]{0x0A,0x0A,0x1B,0x61,0x00});out.flush();socket.close();runOnUiThread(()->toast("Label barcode dikirim (kertas "+width+" mm)"));}catch(Exception e){runOnUiThread(()->toast("Gagal mencetak label: "+e.getMessage()));}}).start();}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data); IntentResult scanResult=IntentIntegrator.parseActivityResult(req,res,data); if(scanResult!=null){if(scanResult.getContents()!=null){if(scanInput!=null)scanInput.setText("");addScanned(scanResult.getContents());}return;} if(res!=RESULT_OK||data==null)return; Uri uri=data.getData();try{
        if(req==101){ db.close(); try(InputStream in=new FileInputStream(getDatabasePath("ariestronic.db"));OutputStream out=getContentResolver().openOutputStream(uri)){copy(in,out);} db=new DB(this);toast("Backup berhasil disimpan"); }
        else if(req==102){ db.close(); File base=getDatabasePath("ariestronic.db"); new File(base+"-wal").delete(); new File(base+"-shm").delete(); File temp=new File(getFilesDir(),"restore.tmp"); try(InputStream in=getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(temp)){copy(in,out);} if(!temp.renameTo(base)){try(InputStream in=new FileInputStream(temp);OutputStream out=new FileOutputStream(base)){copy(in,out);}temp.delete();} db=new DB(this);cart.clear();toast("Backup dipulihkan");showHome(); }
    }catch(Exception e){db=new DB(this);toast("Gagal: "+e.getMessage());}}
    private void copy(InputStream in,OutputStream out)throws IOException{byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);out.flush();}
    private long parse(String s){try{return Long.parseLong(s.trim());}catch(Exception e){return 0;}}

    static class Product {int id,stock;String name,barcode;long price,costPrice; Product(int i,String n,String b,long p,int s){this(i,n,b,0,p,s);} Product(int i,String n,String b,long co,long p,int s){id=i;name=n;barcode=b;costPrice=co;price=p;stock=s;}}
    static class CartItem {Product product;int qty;CartItem(Product p,int q){product=p;qty=q;}}
    static class DB extends SQLiteOpenHelper {
        DB(Context c){super(c,"ariestronic.db",null,3);} public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,barcode TEXT UNIQUE NOT NULL,cost_price INTEGER NOT NULL DEFAULT 0,price INTEGER NOT NULL,stock INTEGER NOT NULL)");d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT,total INTEGER,cash INTEGER)");d.execSQL("CREATE TABLE sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT,sale_id INTEGER,product_name TEXT,qty INTEGER,price INTEGER,cost_price INTEGER NOT NULL DEFAULT 0)");d.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT)");} public void onUpgrade(SQLiteDatabase d,int o,int n){if(o<2)d.execSQL("ALTER TABLE products ADD COLUMN cost_price INTEGER NOT NULL DEFAULT 0");if(o<3)d.execSQL("ALTER TABLE sale_items ADD COLUMN cost_price INTEGER NOT NULL DEFAULT 0");}
        Product byBarcode(String b){Cursor c=getReadableDatabase().rawQuery("SELECT id,name,barcode,cost_price,price,stock FROM products WHERE barcode=?",new String[]{b});Product p=null;if(c.moveToFirst())p=new Product(c.getInt(0),c.getString(1),c.getString(2),c.getLong(3),c.getLong(4),c.getInt(5));c.close();return p;}
        boolean upsert(String n,String b,long co,long p,int s){try{SQLiteDatabase d=getWritableDatabase();ContentValues v=new ContentValues();v.put("name",n);v.put("barcode",b);v.put("cost_price",co);v.put("price",p);v.put("stock",s);d.insertOrThrow("products",null,v);return true;}catch(Exception e){return false;}}
        void updatePriceStock(int id,long co,long p,int s){ContentValues v=new ContentValues();v.put("cost_price",co);v.put("price",p);v.put("stock",s);getWritableDatabase().update("products",v,"id=?",new String[]{String.valueOf(id)});}
        boolean updateProduct(int id,String name,String barcode,long cost,long price,int stock){try{ContentValues v=new ContentValues();v.put("name",name);v.put("barcode",barcode);v.put("cost_price",cost);v.put("price",price);v.put("stock",stock);getWritableDatabase().update("products",v,"id=?",new String[]{String.valueOf(id)});return true;}catch(Exception e){return false;}}
        Cursor getProducts(){return getReadableDatabase().rawQuery("SELECT id,name,barcode,cost_price,price,stock FROM products ORDER BY name",null);}
        long saveSale(ArrayList<CartItem> cart,long total,long cash){SQLiteDatabase d=getWritableDatabase();d.beginTransaction();long id=-1;try{ContentValues s=new ContentValues();s.put("created_at",new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(new Date()));s.put("total",total);s.put("cash",cash);id=d.insertOrThrow("sales",null,s);for(CartItem x:cart){Cursor stockCursor=d.rawQuery("SELECT stock,price,cost_price,name FROM products WHERE id=?",new String[]{String.valueOf(x.product.id)}); if(!stockCursor.moveToFirst()){stockCursor.close();throw new IllegalStateException("Barang tidak ditemukan: "+x.product.name);} int available=stockCursor.getInt(0); long currentPrice=stockCursor.getLong(1), currentCost=stockCursor.getLong(2); String currentName=stockCursor.getString(3); stockCursor.close(); if(available<x.qty)throw new IllegalStateException("Stok "+currentName+" hanya tersisa "+available); ContentValues it=new ContentValues();it.put("sale_id",id);it.put("product_name",currentName);it.put("qty",x.qty);it.put("price",currentPrice);it.put("cost_price",currentCost);d.insert("sale_items",null,it);d.execSQL("UPDATE products SET stock=stock-? WHERE id=?",new Object[]{x.qty,x.product.id});}d.setTransactionSuccessful();}finally{d.endTransaction();}return id;}
        long totalProfit(){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM((price-cost_price)*qty),0) FROM sale_items",null);c.moveToFirst();long n=c.getLong(0);c.close();return n;} long salesToday(){String day=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(new Date());Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(total),0) FROM sales WHERE substr(created_at,1,10)=?",new String[]{day});c.moveToFirst();long n=c.getLong(0);c.close();return n;} long salesThisMonth(){String month=new java.text.SimpleDateFormat("yyyy-MM",Locale.getDefault()).format(new Date());Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(total),0) FROM sales WHERE substr(created_at,1,7)=?",new String[]{month});c.moveToFirst();long n=c.getLong(0);c.close();return n;} long totalSales(){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(total),0) FROM sales",null);c.moveToFirst();long n=c.getLong(0);c.close();return n;} int saleCount(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM sales",null);c.moveToFirst();int n=c.getInt(0);c.close();return n;} Cursor sales(){return getReadableDatabase().rawQuery("SELECT id,created_at,total FROM sales ORDER BY id DESC LIMIT 30",null);}
        String setting(String k,String def){Cursor c=getReadableDatabase().rawQuery("SELECT v FROM settings WHERE k=?",new String[]{k});String s=def;if(c.moveToFirst())s=c.getString(0);c.close();return s;} void setSetting(String k,String v){ContentValues c=new ContentValues();c.put("k",k);c.put("v",v);getWritableDatabase().insertWithOnConflict("settings",null,c,SQLiteDatabase.CONFLICT_REPLACE);}
    }
}
