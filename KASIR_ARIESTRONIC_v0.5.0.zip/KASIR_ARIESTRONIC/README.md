# KASIR ARIESTRONIC — proyek Android v0.5.0

Aplikasi kasir satu perangkat Android, tema hijau muda dan putih, tanpa PIN. Data transaksi disimpan di SQLite lokal agar kasir tetap dapat dipakai offline.

## Fitur di source proyek
- Profil toko: nama, alamat, dan nomor HP.
- Data barang: nama, barcode, harga modal, harga jual, dan stok.
- Tambah barang dan pembuatan kode barang internal otomatis.
- Pencarian daftar barang berdasarkan nama atau barcode.
- Edit nama, barcode, harga modal, harga jual, dan stok.
- Peringatan visual stok menipis (stok 1–5) dan stok habis.
- Scanner Bluetooth/USB OTG mode keyboard HID: scan ke kolom barcode dan akhiri dengan Enter.
- Pemindaian kamera HP menggunakan ZXing.
- Keranjang dengan tombol tambah/kurangi jumlah dan hapus item.
- Pembayaran tunai, kembalian, penyimpanan transaksi, dan pengurangan stok. Harga serta stok diperbarui dari database sebelum pembayaran; validasi stok dilakukan lagi saat transaksi disimpan.
- Riwayat transaksi, omzet hari ini/bulan ini, total omzet, dan estimasi laba kotor.
- Pilih printer Bluetooth Classic SPP yang sudah dipasangkan, cetak struk ESC/POS dan label barcode Code 128.
- Pengaturan lebar kertas 58/80 mm.
- Backup dan restore database manual melalui pemilih dokumen Android; pilih Google Drive sebagai lokasi jika tersedia.

## Batasan dan kompatibilitas
- ZIP ini berisi **source proyek Android, bukan APK siap pasang**. APK belum berhasil dibangun atau diuji pada perangkat fisik.
- Backup Google Drive dilakukan manual melalui Android Storage Access Framework. Belum ada backup otomatis/background atau sinkronisasi cloud.
- Scanner Bluetooth/USB didukung bila scanner bertindak sebagai keyboard HID. Scanner serial/vendor-specific memerlukan integrasi tambahan.
- Printer didukung bila printer thermal Bluetooth Classic SPP kompatibel ESC/POS. Printer BLE-only atau protokol vendor khusus mungkin tidak kompatibel.
- Dukungan printer dan label perlu diuji pada model printer, lebar media, dan ukuran label yang sebenarnya. Pengaturan 58/80 mm memformat struk; itu tidak menjamin semua ukuran gulungan label cocok.
- Pemindaian kamera memakai ZXing dan memerlukan izin kamera saat pertama kali dipakai.
- Uji transaksi dengan data percobaan terlebih dahulu. Buat backup sebelum memakai aplikasi untuk pembukuan toko.

## Cara membangun APK
Diperlukan komputer (Windows/macOS/Linux) dengan Android Studio, JDK 17 atau lebih baru, Android SDK Platform 35, serta koneksi internet saat Gradle mengunduh dependensi. Lingkungan pengerjaan saat ini tidak memiliki Android SDK/Gradle dan tidak dapat mengakses internet, sehingga APK tidak dapat dibangun di sini.

1. Ekstrak ZIP.
2. Buka folder `KASIR_ARIESTRONIC` di Android Studio.
3. Tunggu Gradle Sync selesai.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Jika build berhasil, APK debug berada di `app/build/outputs/apk/debug/app-debug.apk`.

Konfigurasi: Android Gradle Plugin 8.7.3, Gradle 8.9 (Android Studio dapat mengunduh wrapper/distribusi yang diperlukan), compile SDK 35, target SDK 32, min SDK 23, Java 17.

## Catatan versi 0.5.0
- Menambahkan peringatan visual untuk barang dengan stok menipis (1–5) dan stok habis (0).
- Menaikkan versionCode menjadi 5 dan versionName menjadi 0.5.0.
- APK tetap belum dibangun dan belum diuji pada HP, scanner, atau printer fisik.

## Build APK tanpa komputer (menggunakan HP Android)
Proyek ini menyertakan GitHub Actions di `.github/workflows/build-apk.yml` agar proses build bisa dijalankan di server GitHub.

1. Di HP, buka GitHub melalui browser dan masuk/daftar akun.
2. Buat repository baru bernama `kasir-ariestronic` (Public atau Private).
3. Ekstrak ZIP proyek di HP menggunakan aplikasi pengelola file.
4. Unggah isi folder `KASIR_ARIESTRONIC` ke repository GitHub, pertahankan struktur folder termasuk `.github/workflows/build-apk.yml`.
5. Buka tab **Actions**, pilih **Build KASIR ARIESTRONIC APK**, lalu tekan **Run workflow** bila build belum berjalan otomatis.
6. Tunggu sampai workflow berstatus hijau. Buka hasil run, cari bagian **Artifacts**, lalu unduh `KASIR-ARIESTRONIC-debug-apk`.
7. Ekstrak file artifact ZIP untuk mendapatkan `app-debug.apk`. Buka APK di HP dan izinkan pemasangan dari sumber tersebut jika Android memintanya.

Catatan: GitHub membangun APK di server, bukan di HP. Repository dan artifact dapat memuat kode aplikasi; jangan unggah data toko, database pelanggan, atau kredensial pribadi. APK debug untuk uji coba, bukan rilis produksi bertanda tangan. Uji transaksi, backup, scanner, dan printer sebelum dipakai untuk pembukuan sungguhan.
